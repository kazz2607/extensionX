(function(){(function(){"use strict";if(document.getElementById(`__xmd_snackbar__`))return;let e=document.createElement(`style`);e.id=`__xmd_snackbar_style__`,e.textContent=`
    #__xmd_snackbar__ {
      position: fixed;
      bottom: 28px;
      left: 50%;
      transform: translateX(-50%) translateY(120px);
      z-index: 2147483646;
      min-width: 340px;
      max-width: min(560px, calc(100vw - 40px));
      background: rgba(12, 12, 14, 0.92);
      border: 1px solid rgba(255,255,255,0.10);
      border-radius: 16px;
      padding: 14px 18px 12px;
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      box-shadow: 0 8px 40px rgba(0,0,0,0.55), 0 0 0 1px rgba(29,155,240,0.15);
      font-family: -apple-system, 'Inter', BlinkMacSystemFont, sans-serif;
      font-size: 13px;
      color: #f0f0f0;
      pointer-events: all;
      transition: transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1),
                  opacity  0.3s ease;
      opacity: 0;
      user-select: none;
    }

    #__xmd_snackbar__.visible {
      transform: translateX(-50%) translateY(0);
      opacity: 1;
    }

    #__xmd_snackbar__.hiding {
      transform: translateX(-50%) translateY(120px);
      opacity: 0;
    }

    /* ── Header row ── */
    .__xmd_sb_header__ {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 10px;
    }

    .__xmd_sb_title__ {
      font-size: 12px;
      font-weight: 600;
      color: rgba(255,255,255,0.75);
      display: flex;
      align-items: center;
      gap: 6px;
      flex: 1;
      min-width: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .__xmd_sb_title__ span {
      color: #1D9BF0;
    }

    .__xmd_sb_close__ {
      width: 22px;
      height: 22px;
      border: none;
      background: rgba(255,255,255,0.08);
      border-radius: 50%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      color: rgba(255,255,255,0.5);
      flex-shrink: 0;
      transition: background 0.15s, color 0.15s;
      line-height: 1;
      padding: 0;
    }

    .__xmd_sb_close__:hover {
      background: rgba(255,255,255,0.16);
      color: white;
    }

    /* ── Progress bar ── */
    .__xmd_sb_bar_wrap__ {
      width: 100%;
      height: 6px;
      background: rgba(255,255,255,0.08);
      border-radius: 3px;
      overflow: hidden;
      margin-bottom: 8px;
    }

    .__xmd_sb_bar__ {
      height: 100%;
      border-radius: 3px;
      background: linear-gradient(90deg, #1D9BF0, #a855f7);
      background-size: 200% 100%;
      transition: width 0.4s ease;
      position: relative;
    }

    /* Shimmer animation khi đang tải */
    .__xmd_sb_bar__.active {
      animation: __xmd_sb_shimmer__ 1.6s linear infinite;
    }

    @keyframes __xmd_sb_shimmer__ {
      0%   { background-position: 200% center; }
      100% { background-position: -200% center; }
    }

    /* ── Stats row ── */
    .__xmd_sb_stats__ {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .__xmd_sb_counter__ {
      font-size: 11px;
      color: rgba(255,255,255,0.45);
      font-variant-numeric: tabular-nums;
    }

    .__xmd_sb_counter__ b {
      color: #1D9BF0;
      font-weight: 600;
    }

    .__xmd_sb_filename__ {
      font-size: 10px;
      color: rgba(255,255,255,0.3);
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: right;
    }

    /* ── Done state ── */
    #__xmd_snackbar__.done .__xmd_sb_bar_wrap__ {
      display: none;
    }

    #__xmd_snackbar__.done .__xmd_sb_stats__ {
      display: none;
    }

    #__xmd_snackbar__.done .__xmd_sb_header__ {
      margin-bottom: 0;
    }

    .__xmd_sb_done_msg__ {
      display: none;
      font-size: 12px;
      color: rgba(255,255,255,0.65);
      align-items: center;
      gap: 6px;
    }

    #__xmd_snackbar__.done .__xmd_sb_done_msg__ {
      display: flex;
    }

    .__xmd_sb_done_success__ { color: #00ba7c; font-weight: 600; }
    .__xmd_sb_done_failed__  { color: #f4212e; font-weight: 600; }
  `,document.documentElement.appendChild(e);let t=document.createElement(`div`);t.id=`__xmd_snackbar__`,t.innerHTML=`
    <div class="__xmd_sb_header__">
      <div class="__xmd_sb_title__" id="__xmd_sb_title__">
        ⬇ Đang tải <span id="__xmd_sb_username__">...</span>
      </div>
      <button class="__xmd_sb_close__" id="__xmd_sb_close__" title="Đóng">✕</button>
    </div>
    <div class="__xmd_sb_bar_wrap__">
      <div class="__xmd_sb_bar__ active" id="__xmd_sb_bar__" style="width:0%"></div>
    </div>
    <div class="__xmd_sb_stats__">
      <div class="__xmd_sb_counter__" id="__xmd_sb_counter__">0 / 0</div>
      <div class="__xmd_sb_filename__" id="__xmd_sb_filename__"></div>
    </div>
    <div class="__xmd_sb_done_msg__" id="__xmd_sb_done_msg__"></div>
  `,document.documentElement.appendChild(t),document.getElementById(`__xmd_sb_title__`);let n=document.getElementById(`__xmd_sb_username__`),r=document.getElementById(`__xmd_sb_close__`),i=document.getElementById(`__xmd_sb_bar__`),a=document.getElementById(`__xmd_sb_counter__`),o=document.getElementById(`__xmd_sb_filename__`),s=document.getElementById(`__xmd_sb_done_msg__`),c=null;function l(){clearTimeout(c),t.classList.remove(`hiding`,`done`),t.offsetWidth,t.classList.add(`visible`)}function u(e=!1){clearTimeout(c),e?(t.classList.remove(`visible`),t.classList.remove(`hiding`)):(t.classList.add(`hiding`),setTimeout(()=>{t.classList.remove(`visible`,`hiding`)},350))}function d(e=3e3){clearTimeout(c),c=setTimeout(()=>u(),e)}function f(e,t,n,r=0){let i=document.createElement(`b`);if(i.textContent=`${e}%`,a.replaceChildren(i,document.createTextNode(`  ${t} / ${n}`)),r>0){let e=document.createElement(`span`);e.style.color=`#f4212e`,e.textContent=`✗ ${r}`,a.append(`  (`,e,`)`)}}function p(e,t,n){let r=document.createElement(`span`);if(r.className=`__xmd_sb_done_success__`,r.textContent=`${e} file`,s.replaceChildren(document.createTextNode(`✅  `),r),n&&s.append(` từ @${n}`),t>0){let e=document.createElement(`span`);e.className=`__xmd_sb_done_failed__`,e.textContent=`✗ ${t} lỗi`,s.append(`  —  `,e)}}r.addEventListener(`click`,e=>{e.stopPropagation(),u()}),window.addEventListener(`XMD_SNACKBAR_UPDATE`,e=>{let r=e.detail||{};switch(r.type){case`DOWNLOAD_STARTED`:t.classList.remove(`done`),n.textContent=r.username?`@`+String(r.username):``,i.style.width=`0%`,i.classList.add(`active`),a.textContent=`0 / `+(r.total||0),o.textContent=``,s.replaceChildren(),l();break;case`DOWNLOAD_PROGRESS`:{let e=Math.min(r.percent||0,100),t=r.current||0,n=r.total||0;r.success;let a=r.failed||0;i.style.width=e+`%`,f(e,t,n,a),r.currentFile&&(o.textContent=r.currentFile),r.done&&(i.style.width=`100%`);break}case`ACTIVE_DOWNLOADS_UPDATE`:{if(!r.activeList||r.activeList.length===0)break;let e=r.activeList[0],t=e=>(e/1024/1024).toFixed(1)+` MB`,n=(e.speedBps/1024/1024).toFixed(1)+` MB/s`,i=e.totalBytes?Math.round(e.bytesReceived/e.totalBytes*100)+`%`:t(e.bytesReceived);o.textContent=`${e.filename} (${i} • ${n})`;break}case`DOWNLOAD_DONE`:{let e=r.success||0,n=r.failed||0;r.total,i.style.width=`100%`,i.classList.remove(`active`),t.classList.add(`done`),p(e,n,typeof r.username==`string`?r.username:``),d(3500);break}}})})()})();
(function(){(function(){"use strict";if(window.__XMD_TWEET_BTN_LOADED__)return;window.__XMD_TWEET_BTN_LOADED__=!0;let e=document.createElement(`style`);e.id=`__xmd_tweet_btn_style__`,e.textContent=`
    /* Nút download mini trên từng tweet */
    .xmd-dl-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 34px;
      height: 34px;
      border: none;
      border-radius: 50%;
      background: transparent;
      cursor: pointer;
      padding: 0;
      margin: 0;
      color: rgb(83, 100, 113);
      transition: background 0.15s, color 0.15s, transform 0.15s;
      position: relative;
      vertical-align: middle;
      flex-shrink: 0;
    }

    .xmd-dl-btn:hover {
      background: rgba(29, 155, 240, 0.1);
      color: rgb(29, 155, 240);
    }

    .xmd-dl-btn:active {
      transform: scale(0.9);
    }

    /* Dark mode support — X.com sets [data-theme] on html or body */
    @media (prefers-color-scheme: dark) {
      .xmd-dl-btn {
        color: rgb(113, 118, 123);
      }
    }

    /* State: loading */
    .xmd-dl-btn.xmd-loading .xmd-icon-idle,
    .xmd-dl-btn.xmd-loading .xmd-icon-done,
    .xmd-dl-btn.xmd-loading .xmd-icon-error {
      display: none;
    }
    .xmd-dl-btn.xmd-loading .xmd-icon-spin {
      display: block;
      animation: xmd-spin 0.8s linear infinite;
    }
    .xmd-dl-btn:not(.xmd-loading) .xmd-icon-spin { display: none; }

    /* State: done */
    .xmd-dl-btn.xmd-done .xmd-icon-idle,
    .xmd-dl-btn.xmd-done .xmd-icon-spin,
    .xmd-dl-btn.xmd-done .xmd-icon-error {
      display: none;
    }
    .xmd-dl-btn.xmd-done {
      color: rgb(0, 186, 124);
    }
    .xmd-dl-btn.xmd-done .xmd-icon-done { display: block; }
    .xmd-dl-btn:not(.xmd-done) .xmd-icon-done { display: none; }

    /* State: error */
    .xmd-dl-btn.xmd-error .xmd-icon-idle,
    .xmd-dl-btn.xmd-error .xmd-icon-spin,
    .xmd-dl-btn.xmd-error .xmd-icon-done {
      display: none;
    }
    .xmd-dl-btn.xmd-error {
      color: rgb(244, 33, 46);
    }
    .xmd-dl-btn.xmd-error .xmd-icon-error { display: block; }
    .xmd-dl-btn:not(.xmd-error) .xmd-icon-error { display: none; }

    @keyframes xmd-spin {
      from { transform: rotate(0deg); }
      to   { transform: rotate(360deg); }
    }

    /* Tooltip */
    .xmd-dl-btn[title] {
      position: relative;
    }

    /* Wrapper để canh lề đồng đều với các nút khác */
    .xmd-dl-wrapper {
      display: inline-flex;
      align-items: center;
    }
  `,document.documentElement.appendChild(e);let t={download:`<svg class="xmd-icon-idle" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="7 10 12 15 17 10"/>
      <line x1="12" y1="15" x2="12" y2="3"/>
    </svg>`,spin:`<svg class="xmd-icon-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
      <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/>
      <path d="M12 2a10 10 0 0 1 10 10" stroke-opacity="1"/>
    </svg>`,done:`<svg class="xmd-icon-done" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>`,error:`<svg class="xmd-icon-error" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <line x1="18" y1="6" x2="6" y2="18"/>
      <line x1="6" y1="6" x2="18" y2="18"/>
    </svg>`};function n(e){if(!e)return``;let t=e.querySelector(`a[href*="/status/"]`);if(t){let e=t.href.match(/\/status\/(\d+)/);if(e)return e[1]}let n=e.querySelector(`time`)?.closest(`a`);if(n){let e=n.href?.match(/\/status\/(\d+)/);if(e)return e[1]}return``}function r(e){let t=e.querySelectorAll(`img[src*="pbs.twimg.com"]`);for(let e of t){let t=e.src||``;if(!t.includes(`profile_images`)&&!t.includes(`profile_banners`)&&!t.includes(`emoji`))return!0}return!!(e.querySelector(`video`)||e.querySelector(`img[src*="video_thumb"]`))}function i(){try{let e=location.pathname.match(/^\/([A-Za-z0-9_]{1,50})/);if(e&&![`home`,`explore`,`notifications`,`messages`,`search`,`settings`,`i`,`login`,`logout`,`compose`].includes(e[1].toLowerCase()))return e[1]}catch{}return``}let a=new Map;function o(e){let n=document.createElement(`button`);return n.className=`xmd-dl-btn`,n.setAttribute(`data-xmd-btn`,e),n.setAttribute(`title`,`Download media (X Media Downloader)`),n.setAttribute(`aria-label`,`Download tweet media`),n.innerHTML=t.download+t.spin+t.done+t.error,n.addEventListener(`click`,t=>{if(t.stopPropagation(),t.preventDefault(),n.classList.contains(`xmd-loading`))return;s(e,`loading`);let r=i();window.dispatchEvent(new CustomEvent(`XMD_TWEET_DOWNLOAD`,{detail:{tweetId:e,username:r}}))}),n}function s(e,t){let n=a.get(e);if(!n)return;let r=n.__xmdTimer;r&&(clearTimeout(r),n.__xmdTimer=null),n.classList.remove(`xmd-loading`,`xmd-done`,`xmd-error`),t===`loading`?(n.classList.add(`xmd-loading`),n.title=`Đang tải...`):t===`done`?(n.classList.add(`xmd-done`),n.title=`Đã tải xong! ✓`,n.__xmdTimer=setTimeout(()=>{n.classList.remove(`xmd-done`),n.title=`Download media (X Media Downloader)`},3e3)):t===`error`&&(n.classList.add(`xmd-error`),n.title=`Lỗi! Thử lại`,n.__xmdTimer=setTimeout(()=>{n.classList.remove(`xmd-error`),n.title=`Download media (X Media Downloader)`},3e3))}function c(e){if(e.querySelector(`[data-xmd-btn]`)||!r(e))return;let t=n(e);if(!t)return;let i=e.querySelectorAll(`div[role="group"]`),s=i[i.length-1];if(!s)return;let c=o(t),l=document.createElement(`div`);l.className=`xmd-dl-wrapper`,l.appendChild(c),s.appendChild(l),a.set(t,c)}function l(){document.querySelectorAll(`article`).forEach(c)}let u,d=new MutationObserver(e=>{e.some(e=>Array.from(e.addedNodes).some(e=>e.nodeType===1&&(e.tagName===`ARTICLE`||e.querySelector?.(`article`))))&&(clearTimeout(u),u=setTimeout(l,500))});function f(){document.body?d.observe(document.body,{childList:!0,subtree:!0}):document.addEventListener(`DOMContentLoaded`,()=>{d.observe(document.body,{childList:!0,subtree:!0})},{once:!0})}f(),setTimeout(l,1e3),setTimeout(l,2500),window.addEventListener(`XMD_TWEET_BTN_UPDATE`,e=>{let{tweetId:t,state:n}=e.detail||{};!t||!n||s(t,n)});let p=location.pathname;function m(){location.pathname!==p&&(p=location.pathname,a.clear(),setTimeout(l,1500),setTimeout(l,3e3))}window.addEventListener(`popstate`,m);for(let e of[`pushState`,`replaceState`]){let t=history[e];history[e]=function(...e){let n=t.apply(this,e);return queueMicrotask(m),n}}})()})();
(function(){(function(){"use strict";if(document.getElementById(`__xmd_fab__`))return;let e=document.createElement(`style`);e.id=`__xmd_fab_style__`,e.textContent=`
    #__xmd_fab__ {
      position: fixed;
      top: 60%;
      right: 20px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 8px;
      font-family: -apple-system, 'Inter', BlinkMacSystemFont, sans-serif;
      pointer-events: none;
      /* Smooth transition chỉ khi không đang kéo */
      transition: top 0s;
    }

    #__xmd_fab__.dragging {
      transition: none !important;
    }

    #__xmd_fab__ * { box-sizing: border-box; }

    /* ── Drag Handle ── */
    #__xmd_drag_handle__ {
      width: 36px;
      height: 16px;
      background: rgba(255,255,255,0.10);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 8px;
      cursor: grab;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: all;
      transition: background 0.15s, border-color 0.15s;
      align-self: auto;
      user-select: none;
      -webkit-user-select: none;
      margin-bottom: 10px;
    }

    #__xmd_drag_handle__:hover {
      background: rgba(29,155,240,0.22);
      border-color: rgba(29,155,240,0.35);
    }

    #__xmd_drag_handle__.grabbing {
      cursor: grabbing;
      background: rgba(29,155,240,0.3);
      border-color: rgba(29,155,240,0.5);
    }

    /* Info panel */
    #__xmd_panel__ {
      background: rgba(15, 15, 15, 0.96);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 14px;
      padding: 10px 14px;
      backdrop-filter: blur(20px);
      min-width: 180px;
      pointer-events: all;
      transform: translateX(220px);
      transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), opacity 0.2s;
      opacity: 0;
      box-shadow: 0 8px 32px rgba(0,0,0,0.6), 0 0 0 1px rgba(29,155,240,0.2);
    }

    #__xmd_panel__.visible {
      transform: translateX(0);
      opacity: 1;
    }

    .__xmd_panel_row__ {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 8px;
    }

    .__xmd_panel_row__:last-child { margin-bottom: 0; }

    .__xmd_label__ {
      font-size: 11px;
      color: rgba(255,255,255,0.5);
      font-weight: 400;
    }

    .__xmd_count__ {
      font-size: 16px;
      font-weight: 700;
      color: #1D9BF0;
      font-variant-numeric: tabular-nums;
    }

    .__xmd_divider__ {
      height: 1px;
      background: rgba(255,255,255,0.08);
      margin: 8px 0;
    }

    .__xmd_btn_row__ {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 6px;
    }

    .__xmd_panel_btn__ {
      padding: 7px 10px;
      border: none;
      border-radius: 8px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
      transition: all 0.15s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
    }

    .__xmd_btn_icon__ {
      width: 13px;
      height: 13px;
      flex: 0 0 13px;
      stroke: currentColor;
    }

    .__xmd_icon_stop__ { display: none; }
    .__xmd_btn_collect__.active .__xmd_icon_play__ { display: none; }
    .__xmd_btn_collect__.active .__xmd_icon_stop__ { display: block; }

    .__xmd_panel_btn__:hover { transform: scale(1.04); }

    .__xmd_btn_collect__ {
      background: rgba(29,155,240,0.2);
      color: #1D9BF0;
      border: 1px solid rgba(29,155,240,0.3);
    }

    .__xmd_btn_collect__.active {
      background: rgba(244,33,46,0.2);
      color: #f4212e;
      border-color: rgba(244,33,46,0.3);
    }

    .__xmd_btn_download__ {
      background: rgba(0,186,124,0.15);
      color: #00ba7c;
      border: 1px solid rgba(0,186,124,0.3);
    }

    .__xmd_btn_download__:disabled {
      opacity: 0.4;
      cursor: not-allowed;
    }

    /* Main FAB button */
    #__xmd_main_btn__ {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: linear-gradient(135deg, #1D9BF0, #a855f7);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 20px rgba(29,155,240,0.5), 0 0 0 0 rgba(29,155,240,0.4);
      transition: all 0.2s;
      position: relative;
      pointer-events: all;
      animation: __xmd_pulse__ 3s infinite;
      color: white;
    }

    @keyframes __xmd_pulse__ {
      0%   { box-shadow: 0 4px 20px rgba(29,155,240,0.5), 0 0 0 0 rgba(29,155,240,0.4); }
      70%  { box-shadow: 0 4px 20px rgba(29,155,240,0.5), 0 0 0 10px rgba(29,155,240,0); }
      100% { box-shadow: 0 4px 20px rgba(29,155,240,0.5), 0 0 0 0 rgba(29,155,240,0); }
    }

    #__xmd_main_btn__:hover { transform: scale(1.1); }
    #__xmd_main_btn__:active { transform: scale(0.95); }

    /* Ẩn hover effect khi đang kéo */
    #__xmd_fab__.dragging #__xmd_main_btn__:hover { transform: none; }

    /* Badge */
    #__xmd_badge__ {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #f4212e;
      color: white;
      font-size: 9px;
      font-weight: 700;
      min-width: 18px;
      height: 18px;
      border-radius: 9px;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0 4px;
      border: 2px solid rgba(15,15,15,0.9);
      display: none;
    }

    /* Collecting spinner on FAB */
    #__xmd_main_btn__.collecting {
      animation: __xmd_spin_pulse__ 2s linear infinite;
    }

    @keyframes __xmd_spin_pulse__ {
      0%   { box-shadow: 0 0 0 0 rgba(244,33,46,0.5); }
      50%  { box-shadow: 0 0 0 12px rgba(244,33,46,0); }
      100% { box-shadow: 0 0 0 0 rgba(244,33,46,0); }
    }

    /* Scrolling stats mini */
    .__xmd_scroll_info__ {
      font-size: 10px;
      color: #00ba7c;
      text-align: center;
      padding-top: 6px;
      display: none;
    }

    .__xmd_scroll_info__.visible { display: block; }
  `,document.documentElement.appendChild(e);let t=document.createElement(`div`);t.id=`__xmd_fab__`,t.innerHTML=`
    <div id="__xmd_panel__">
      <div class="__xmd_panel_row__">
        <span class="__xmd_label__" id="__xmd_lbl_media__">Media thu thập</span>
        <span class="__xmd_count__" id="__xmd_count__">0</span>
      </div>
      <div class="__xmd_panel_row__">
        <span class="__xmd_label__" id="__xmd_lbl_scroll__">Scroll</span>
        <span class="__xmd_count__" id="__xmd_scrolls__" style="font-size:13px;color:#888">0</span>
      </div>
      <div class="__xmd_divider__"></div>
      <div class="__xmd_btn_row__">
        <button class="__xmd_panel_btn__ __xmd_btn_collect__" id="__xmd_collect_btn__">
          <svg class="__xmd_btn_icon__ __xmd_icon_play__" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M8 5v14l11-7z"/>
          </svg>
          <svg class="__xmd_btn_icon__ __xmd_icon_stop__" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M7 7h10v10H7z"/>
          </svg>
          <span class="__xmd_btn_text__">Thu Thập</span>
        </button>
        <button class="__xmd_panel_btn__ __xmd_btn_download__" id="__xmd_download_btn__" disabled>
          <svg class="__xmd_btn_icon__" viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M12 3v12"/>
            <path d="m7 10 5 5 5-5"/>
            <path d="M5 21h14"/>
          </svg>
          <span class="__xmd_btn_text__">Download</span>
        </button>
      </div>
      <div class="__xmd_scroll_info__" id="__xmd_scroll_info__">
        ⟳ Đang scroll tự động...
      </div>
    </div>
    <div id="__xmd_drag_handle__" title="Kéo để di chuyển">
      <svg width="16" height="8" viewBox="0 0 16 8" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="2" y="0.5" width="12" height="1.5" rx="0.75" fill="rgba(255,255,255,0.5)"/>
        <rect x="2" y="3.25" width="12" height="1.5" rx="0.75" fill="rgba(255,255,255,0.5)"/>
        <rect x="2" y="6" width="12" height="1.5" rx="0.75" fill="rgba(255,255,255,0.5)"/>
      </svg>
    </div>
    <button id="__xmd_main_btn__" title="X Media Downloader">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      <span id="__xmd_badge__">0</span>
    </button>
  `,document.documentElement.appendChild(t);let n=!1,r=!1,i=!1,a=0,o=document.getElementById(`__xmd_panel__`),s=document.getElementById(`__xmd_main_btn__`),c=document.getElementById(`__xmd_badge__`),l=document.getElementById(`__xmd_count__`),u=document.getElementById(`__xmd_scrolls__`),d=document.getElementById(`__xmd_collect_btn__`),f=document.getElementById(`__xmd_download_btn__`),p=document.getElementById(`__xmd_scroll_info__`),m=document.getElementById(`__xmd_lbl_media__`),h=document.getElementById(`__xmd_lbl_scroll__`),g=document.getElementById(`__xmd_drag_handle__`);function _(e){return String(e||``).replace(/^(?:[▶⏹↓⏳⟳]\s*)+/u,``).trim()}function v(e,t){let n=e.querySelector(`.__xmd_btn_text__`);n&&(n.textContent=_(t))}function y(){window.i18n&&(m.textContent=window.i18n.t(`fab_media_collected`),h.textContent=window.i18n.t(`fab_scroll`),v(d,r?window.i18n.t(`fab_collect_stop`):window.i18n.t(`fab_collect_start`)),v(f,i?window.i18n.t(`fab_downloading`):window.i18n.t(`fab_download`)),p.textContent=window.i18n.t(`fab_scrolling`))}window.addEventListener(`XMD_LANG_UPDATE`,e=>{window.i18n&&e.detail?.lang&&(window.i18n.lang=e.detail.lang,y())}),s.addEventListener(`click`,()=>{if(i){n=!n,o.classList.toggle(`visible`,n);return}if(a>0){i=!0,window.dispatchEvent(new CustomEvent(`XMD_FAB_ACTION`,{detail:{action:`START_DOWNLOAD`}})),v(f,window.i18n?window.i18n.t(`fab_downloading`):`⏳ Đang tải...`),f.disabled=!0,n=!1,o.classList.remove(`visible`);return}n=!n,o.classList.toggle(`visible`,n)}),document.addEventListener(`click`,e=>{t.contains(e.target)||(n=!1,o.classList.remove(`visible`))},!0),d.addEventListener(`click`,e=>{e.stopPropagation(),r=!r,r?(v(d,window.i18n?window.i18n.t(`fab_collect_stop`):`⏹ Dừng`),d.classList.add(`active`),s.classList.add(`collecting`),p.classList.add(`visible`),window.dispatchEvent(new CustomEvent(`XMD_FAB_ACTION`,{detail:{action:`START_COLLECTING`}}))):(v(d,window.i18n?window.i18n.t(`fab_collect_start`):`▶ Thu Thập`),d.classList.remove(`active`),s.classList.remove(`collecting`),p.classList.remove(`visible`),window.dispatchEvent(new CustomEvent(`XMD_FAB_ACTION`,{detail:{action:`STOP_COLLECTING`}})))}),f.addEventListener(`click`,e=>{e.stopPropagation(),!(f.disabled||i)&&(i=!0,window.dispatchEvent(new CustomEvent(`XMD_FAB_ACTION`,{detail:{action:`START_DOWNLOAD`}})),v(f,window.i18n?window.i18n.t(`fab_downloading`):`⏳ Đang tải...`),f.disabled=!0)}),window.addEventListener(`XMD_FAB_UPDATE`,e=>{let{count:t,scrollCount:n,state:o}=e.detail||{};if(t!==void 0&&(a=t,l.textContent=t,c.textContent=t>999?`999+`:String(t),c.style.display=t>0?`flex`:`none`,f.disabled=t===0),n!==void 0&&(u.textContent=n),o===`COLLECT_DONE`&&(r=!1,v(d,window.i18n?window.i18n.t(`fab_collect_start`):`▶ Thu Thập`),d.classList.remove(`active`),s.classList.remove(`collecting`),p.classList.remove(`visible`)),o===`DOWNLOAD_PROGRESS`&&e.detail.percent!==void 0){let t=e.detail.percent;v(f,`⏳ ${t}% (${e.detail.current}/${e.detail.total})`)}o===`DOWNLOAD_DONE`&&(i=!1,v(f,window.i18n?window.i18n.t(`fab_download`):`↓ Download`),f.disabled=a===0)});let b=`__xmd_fab_top_pct__`;function x(){try{let e=localStorage.getItem(b);if(e!==null){let n=parseFloat(e);if(!isNaN(n)){let e=Math.min(Math.max(n,3),82);t.style.top=e+`%`,t.style.bottom=`auto`}}}catch{}}function S(){try{let e=t.getBoundingClientRect().top/window.innerHeight*100;localStorage.setItem(b,e.toFixed(2))}catch{}}function C(e){let n=t.offsetHeight||100,r=window.innerHeight-n-8;return Math.min(Math.max(e,8),r)}function w(e){t.style.top=e+`px`,t.style.bottom=`auto`}let T=!1,E=!1,D=0,O=0;g.addEventListener(`mousedown`,e=>{e.button===0&&(T=!0,E=!1,D=e.clientY,O=t.getBoundingClientRect().top,t.classList.add(`dragging`),g.classList.add(`grabbing`),document.body.style.userSelect=`none`,e.preventDefault(),e.stopPropagation())}),document.addEventListener(`mousemove`,e=>{if(!T)return;let t=e.clientY-D;!E&&Math.abs(t)>=5&&(E=!0,n=!1,o.classList.remove(`visible`)),E&&w(C(O+t))}),document.addEventListener(`mouseup`,e=>{T&&(T=!1,t.classList.remove(`dragging`),g.classList.remove(`grabbing`),document.body.style.userSelect=``,E&&S(),E=!1)});let k=null,A=0,j=0,M=!1;g.addEventListener(`touchstart`,e=>{if(e.touches.length!==1)return;let n=e.touches[0];k=n.identifier,M=!1,A=n.clientY,j=t.getBoundingClientRect().top,t.classList.add(`dragging`),g.classList.add(`grabbing`),e.preventDefault(),e.stopPropagation()},{passive:!1}),document.addEventListener(`touchmove`,e=>{if(k===null)return;let t=Array.from(e.changedTouches).find(e=>e.identifier===k);if(!t)return;let r=t.clientY-A;!M&&Math.abs(r)>=5&&(M=!0,n=!1,o.classList.remove(`visible`)),M&&(w(C(j+r)),e.preventDefault())},{passive:!1}),document.addEventListener(`touchend`,e=>{Array.from(e.changedTouches).find(e=>e.identifier===k)&&(k=null,t.classList.remove(`dragging`),g.classList.remove(`grabbing`),M&&S(),M=!1)}),window.addEventListener(`resize`,()=>{let e=t.getBoundingClientRect(),n=C(e.top);Math.abs(n-e.top)>1&&(w(n),S())}),x()})()})();